import React from 'react';
import useSignUpForm from './CustomHooks';

const Signup = () => {
  const signup = () => {
    alert(`
Name: ${inputs.firstName} ${inputs.lastName}
Email: ${inputs.email}
Date of Birth: ${inputs.dob}
Phone Number: ${inputs.phoneNumber}
Experience: ${inputs.experience}`);

localStorage.setItem("input",inputs.value)
  }
  const {inputs, handleInputChange, handleSubmit} = useSignUpForm({firstName: '', lastName: '', email: '', dob:'', phoneNumber:'',experience:'',file:'', password1: '', password2: ''}, signup);
  return (
      
      <center>
          <h1> Candidate Details</h1>
          <hr></hr>
    <div className="section is-fullheight" style={{paddingTop:'50px'}}>
      <div className="container">
        <div className="column is-4 is-offset-4">
        <table>
          <div className="box">
          
            <form onSubmit={handleSubmit} autoComplete="off">
            <tr>
                
              <div className="field">
              <td>
                <label className="label has-text-centered">First Name   :</label>
                </td>
                <td>
                <div className="control">
                  <input className="input" type="text" name="firstName" onChange={handleInputChange} value={inputs.firstName}  />
                </div>
                </td>
              </div>
              </tr>
              <tr>
              <div className="field">
              <td>
                <label className="label has-text-centered">Last Name    :</label>
                </td>
                <td>
                <div className="control">
                  <input className="input" type="text" name="lastName" onChange={handleInputChange} value={inputs.lastName} required />
                </div>
                </td>
              </div>
              </tr>
              
              <div className="field">
              <tr>
                  <td>
                <label className="label has-text-centered">Email Address:</label>
                </td>
                
                <td>
                <div className="control">
                  <input className="input" type="text" name="email" onChange={handleInputChange} value={inputs.email} required />
                </div>
                </td>
                </tr>
                <tr>
                    <td>
                <label className="label has-text-centered">Date of Birth    :</label>
                </td>
                    <td>
                
                <div className="control">
                  <input className="input" type="date" name="dob" onChange={handleInputChange} value={inputs.dob} required />
                </div>
                </td>
                </tr>
                <tr>
                    <td>
                <label className="label has-text-centered">Phone Number :</label>
                </td>
                <td>
                <div className="control">
                  <input className="input" type="text" name="phoneNumber" onChange={handleInputChange} value={inputs.phoneNumber} required />
                </div>
                </td>
                </tr>
                <tr>
                    <td>
                <label className="label has-text-centered">Experience</label>
                </td>
                <td>
                <div className="control">
                  <input className="input" type="text" name="experience" onChange={handleInputChange} value={inputs.experience} required />
                </div>
                </td>
                </tr>
                <tr>
                    <td>
                <label className="label has-text-centered">Upload Resume    :</label>
                </td>
                <td>
                <div className="control">
                  <input className="input" type="file" name="file" onChange={handleInputChange} value={inputs.file} required />
                </div>
                </td>
                </tr>
              </div>
              
              <button className="button is-block is-fullwidth is-success" type="submit">Next</button>
            </form>
          </div>
          </table>
        </div>
      </div>
    </div>
    </center>
  )
}

// continue = e =>{
//     e.preventDefault();
//     this.props.nextstep();

// }

export default Signup;