import React, { Component } from 'react';

import MuiThemeProvider  from
 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import {List, ListItem} from 'material-ui/List';
import RaisedButton from 'material-ui/RaisedButton';

export class Confirm extends Component {
    continue = e =>{
        e.preventDefault();
        this.props.nextstep();

    }
    back = e =>{
        e.preventDefault();
        this.props.prevstep();

    }
  render() {
      const { values:{firstname,lastname,email,phoneno,dob,experience}}=this.props;

    return (
      <div>
        <MuiThemeProvider>
            <React.Fragment>
                <AppBar title=" CANDIDATE DETAILS"/><br/><br/>
               <List>
                   <ListItem
                        primaryText="First Name"
                        secondaryText={firstname}
                   />
                                      <ListItem
                        primaryText="Last Name"
                        secondaryText={lastname}
                   />
                                      <ListItem
                        primaryText="Email-id"
                        secondaryText={email}
                   />
                                      <ListItem
                        primaryText="Phone Number"
                        secondaryText={phoneno}
                   />
                                      <ListItem
                        primaryText="Date Of Birth"
                        secondaryText={dob}
                   />
                                      <ListItem
                        primaryText="Experience"
                        secondaryText={experience}
                   />
               </List>
                <RaisedButton 
                label="confirm"
                primary={true}
                style={styles.button}
                onClick={this.continue}
                />

                <RaisedButton 
                label="back"
                primary={true}
                style={styles.button}
                onClick={this.back}
                />
                
            </React.Fragment>
        </MuiThemeProvider>
      </div>
    );
  }
}
const styles={
    button:{
        margin:25
    }
}
export default Confirm