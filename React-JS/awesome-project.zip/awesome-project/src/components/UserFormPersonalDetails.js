import React, { Component } from 'react'
import { Text, View } from 'react-native'

export default class UserFormPersonalDetails extends Component {
  render() {
    return (
      <View>
        <Text> textInComponent </Text>
      </View>
    )
  }
}